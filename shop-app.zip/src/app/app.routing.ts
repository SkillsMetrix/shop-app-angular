import { RouterModule } from "@angular/router";
import { ProductsComponent } from "./component/products/products.component";
import { CartComponent } from "./component/cart/cart.component";



export const APP_ROUTING= RouterModule.forRoot([
    {path:'',component:ProductsComponent},
    {path:'cart',component:CartComponent}

])